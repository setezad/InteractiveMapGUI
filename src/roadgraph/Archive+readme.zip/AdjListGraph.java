/*
 * An extra class to accommodate the needs of the MapGraph class
 * written by Sahba
 */ 
package roadgraph;

import geography.GeographicPoint;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.ArrayList;

class AdjListGraph {
	private int numVertices;
	private int numEdges;
	private HashMap<GeographicPoint,ArrayList<RoadProperty>> adjList;
	
	public AdjListGraph(){
		adjList = new HashMap<GeographicPoint,ArrayList<RoadProperty>>();
		numVertices = 0;
		numEdges = 0;
	}
	// return the number of vertices
	public int getNumV(){
		return numVertices;
	}
	// return the number of edges
	public int getNumE(){
		return numEdges;
	}
	// add a vertex only if it's not already added
	public boolean addGPAsVertex(GeographicPoint key){
		boolean added = false;
		if(key!=null && !adjList.containsKey(key)){
			adjList.put(key, new ArrayList<RoadProperty>());
			added = true;
			numVertices++;
		}
		return added;
	}
	// add an edge 
	//@param two Geographic points as start and end, name and type of the street, the length of the street
	public void addE(GeographicPoint loc1, GeographicPoint loc2, String nameArg, String typeArg, double length){
		adjList.get(loc1).add(new RoadProperty(loc2,nameArg,typeArg,length));
		numEdges++;
	}
	// get the neighbors/ children of a specific vertex
	public List<GeographicPoint> getNeighbors(GeographicPoint loc){
		List<GeographicPoint> neighbors = new ArrayList<GeographicPoint>();
		for(RoadProperty entry:adjList.get(loc)){
			neighbors.add(entry.getLocation());
		}
		return neighbors;
	}
	// check whether a particular node has been added to the graph
	public boolean hasV(GeographicPoint loc){
		return adjList.containsKey(loc);
	}
	// return a set of all vertices added to the graph
	public Set<GeographicPoint> getAllV(){
		return adjList.keySet();
	}
	// print the vertices and their neighbors along with the properties associated to the neighbors
	public void printGraph(){
		for(Map.Entry<GeographicPoint, ArrayList<RoadProperty>> entry: adjList.entrySet()){
			String location = entry.getKey().toString();
			ArrayList<RoadProperty> value = entry.getValue();
			System.out.println(location+" edges: "+value.toString());
			System.out.println("----");
			
		}
		
	}
}

// a class to handle the properties associated to the neighbors
class RoadProperty{
	String name;
	String type;
	double len;
	GeographicPoint end;
	
	RoadProperty(GeographicPoint loc,String arg1, String arg2, double n){
		name = arg1;
		type = arg2;
		len = n;
		end = loc;
	}
	RoadProperty(){
		name = "Street name";
		type = "Street type";
		len = 0;
		end = new GeographicPoint(0,0);
	}
	// return the location of the neighbor
	GeographicPoint getLocation(){
		return end;
	}
	public String toString(){
		return end.toString()+" "+name+" "+type+" "+len+"\n";
	}
}
