package roadgraph;

import geography.GeographicPoint;

public class WeightedMapNode implements Comparable<WeightedMapNode>{
	private double distance;
	private GeographicPoint location;
	// A*
	private double heuristic;
	
	public WeightedMapNode(GeographicPoint loc, double dist){
		distance = dist;
		location = loc;
		heuristic = 0;
	}
	
	public WeightedMapNode(GeographicPoint loc){
		distance = Double.POSITIVE_INFINITY;
		location = loc;
		heuristic = 0;
	}
	
	public GeographicPoint getLocation(){
		return location;
	}
	
	public double getDistance(){
		return distance;
	}
	
	public void setDistance(double dist){
		distance = dist;
	}
	public double getHeuristic(){
		return heuristic;
	}
	public void setHeuristic(double n){
		heuristic = n;
	}
	
	public int compareTo(WeightedMapNode other){
		return Double.compare((this.getDistance()+this.getHeuristic()), (other.getDistance()+other.getHeuristic()));
	}

}
