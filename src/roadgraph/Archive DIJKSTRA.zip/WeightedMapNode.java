package roadgraph;

import geography.GeographicPoint;

public class WeightedMapNode implements Comparable<WeightedMapNode>{
	private double distance;
	private GeographicPoint location;
	
	public WeightedMapNode(GeographicPoint loc, double dist){
		distance = dist;
		location = loc;
	}
	
	public WeightedMapNode(GeographicPoint loc){
		distance = Double.POSITIVE_INFINITY;
		location = loc;
	}
	
	public GeographicPoint getLocation(){
		return location;
	}
	
	public double getDistance(){
		return distance;
	}
	
	public void setDistance(double dist){
		distance = dist;
	}
	
	public int compareTo(WeightedMapNode other){
		return Double.compare(this.getDistance(), other.getDistance());
	}

}
